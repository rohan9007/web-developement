
$(document).ready(function(){


	

		jQuery('button').click(function(){

		


		});




          jQuery('input#result').blur(function(){

            var data=jQuery('input#result').val();

         	if (data=='') {

         		


         	}else{

         	


         	}


         });

            


        jQuery('form#log').submit(function(){


        	var data=jQuery('input#result').val();


        	

        	if (data=='') {

        		jQuery('input#result').blur(function(){


        			

        		});


        		jQuery('h1').html('enter A number');
        		jQuery('input#result').css('background-color','yellow');

        	}else if (data!='') {

        		jQuery('input#result').blur(function(){


        		


        		});

        		


        	}
        	else{

        		jQuery('input#result').blur(function(){
        			
        		


        		});
        	}


        	return false;
        });



        /*------- slider --------*/


        jQuery('.slider').owlCarousel({
        	items    :  1,
        	autoPlay :  true,
        	transitionStyle : 'fade',
        	navigation : true,
        	navigationText: ['<i class="fa fa-chevron-left"></i>','<i class="fa fa-chevron-right"></i>']

        });


        /*--------- gallery popup --------*/

        jQuery('.gallery-image a').prettyPhoto({

        	theme : 'facebook'
        });

     


	
});


