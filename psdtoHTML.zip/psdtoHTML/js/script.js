jQuery(document).ready(function(){

	new WOW().init();
/*
	jQuery('.port-nav').click(function(){

		jQuery('.port-area').mixItUp();

        return false;
	});
*/

    jQuery('.port-mix').mixItUp();

    jQuery('.port-menu a').click(function(){

    	return false;
    });
	

	
});